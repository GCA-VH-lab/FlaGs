# FlaGs
Predicting protein functional association by analysis of conservation of genomic context (Flanking Genes).
